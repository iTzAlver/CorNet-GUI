# - x - x - x - x - x - x - x - x - x - x - x - x - x - x - #
#                                                           #
#   This file was created by: Alberto Palomo Alonso         #
# Universidad de Alcalá - Escuela Politécnica Superior      #
#                                                           #
# - x - x - x - x - x - x - x - x - x - x - x - x - x - x - #
class ColorStyles:
    blue = '#8685cb'
    pink = '#c539b7'
    yellow = '#c8c963'
    gray = '#BBBBBB'
    red = '#c42717'
    orange = '#cc5500'
    black = '#111111'
    green = '#00ff00'
    white = '#cccccc'
# - x - x - x - x - x - x - x - x - x - x - x - x - x - x - #
#                        END OF FILE                        #
# - x - x - x - x - x - x - x - x - x - x - x - x - x - x - #
